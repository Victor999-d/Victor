<?php
include 'includes/db.php'; // Conexão com o banco

$username = "admin";
$email = "admin@exemplo.com";
$password = password_hash("senha123", PASSWORD_DEFAULT); // Criptografar senha

$query = "INSERT INTO usuarios (username, email, password) VALUES (?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("sss", $username, $email, $password);

if ($stmt->execute()) {
    echo "Usuário inserido com sucesso!";
} else {
    echo "Erro ao inserir usuário: " . $conn->error;
}

$stmt->close();
$conn->close();
?>
