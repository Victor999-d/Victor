async function createTask(){
	let formData = new FormData();
	formData.append("creator", localStorage.getItem("id"));
	formData.append("title", title.value);
	formData.append("description", description.value);
	formData.append("deadline", deadline.value)

	if(title.value && deadline.value && description.value){
		let obj = await fetch("api/create_task.php", {
			method: "POST",
			body: formData
		})

		let res = await obj.json();
		if(res.message) alert(res.message);

		if(res.result){
			title.value = "";
			deadline.value = "";
			description.value = "";
 		}
	} else {
		alert("Preencha todos os campos")
	}
}


async function getTasks(){
	let formData = new FormData();
	formData.append("creator", localStorage.getItem("id"));

	let obj = await fetch("api/list_task.php", {
		method: "POST",
		body: formData
	})

	let res = await obj.json();
	if(res.message) alert(res.message);
	else{
		res.data.map((elemento, index)=>{
			if(index >= total_tasks){
				document.querySelector(".task-conteiner").innerHTML+=`
					<div class="task-card">
				  	<span class="task-id">${elemento.id}</span>
				  	<span class="task-title">${elemento.title}</span>
				  	<span class="task-description">${elemento.description}</span>
				  	<span class="task-deadline">${elemento.deadline}</span>
				  	<span class="task-status">${elemento.status}</span>
				  	<div class="actions">
				  		${ elemento.status == "incompleta" ?
				  		`<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#58af9b" onclick="concludeTask(${elemento.id})"><path d="M382-240 154-468l57-57 171 171 367-367 57 57-424 424Z"/></svg>
				  		<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#ff8080" onclick="deleteTask(${elemento.id})"><path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z"/></svg>
				  		` : "Tarefa concluída"
				  		}
				  	</div>
					</div>
				`
			total_tasks++
			}
		})
	}
}

async function	concludeTask(task){
	let formData = new FormData();
	formData.append("task", task);
		let obj = await fetch("api/conclude_task.php", {
			method: "POST",
			body: formData
		})

		let res = await obj.json();
		if(res.message) alert(res.message);

		if(res.result){
			location.href = location.href	
 		}
}

async function	deleteTask(task){
	let formData = new FormData();
	formData.append("task", task);
		let obj = await fetch("api/delete_task.php", {
			method: "POST",
			body: formData
		})

		let res = await obj.json();
		if(res.message) alert(res.message);

		if(res.result){
			location.href = location.href	
 		}
}

let total_tasks = 0

getTasks();
setInterval(()=>{
	getTasks()
}, 500)
let now = new Date();
deadline.setAttribute("min", now.getFullYear()+"-"+(String(now.getMonth()+1).padStart(2, "0"))+"-"+now.getDate());
//deadline.setAttribute("min", now.toLocaleDateString().replaceAll("/", "-"))


function verifyAccount(){
	id_ = localStorage.getItem("id");
    nome_ = localStorage.getItem("nome");
    senha_ = localStorage.getItem("senha");
        

    if(!id_ || !nome_ || !senha_)
    	location.href = "login"
}

function logout(){
	localStorage.clear();
}
verifyAccount()
setInterval(()=>{
	verifyAccount()
}, 500)