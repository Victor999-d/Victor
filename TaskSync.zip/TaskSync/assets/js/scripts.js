const taskCards = document.getElementById('taskCards');
document.addEventListener('DOMContentLoaded', () => {
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    const modal = document.getElementById('taskModal');
    const tasksContainer = document.getElementById('tasksContainer');
    const totalTasksEl = document.getElementById('totalTasks');
    const completedTasksEl = document.getElementById('completedTasks');

    // Função para renderizar os cards
    function renderTasks(filter = 'all') {
        tasksContainer.innerHTML = '';
        const filteredTasks = tasks.filter(task => {
            if (filter === 'completed') return task.completed;
            if (filter === 'pending') return !task.completed;
            return true;
        });

        filteredTasks.forEach((task, index) => {
            const taskEl = document.createElement('div');
            taskEl.className = `task-card ${task.completed ? 'completed' : ''}`;
            taskEl.innerHTML = `
                <div class="priority-tag priority-${task.priority}">
                    ${task.priority.toUpperCase()}
                </div>
                <h3>${task.title}</h3>
                <p>${task.description}</p>
                <div class="task-meta">
                    <span><i class="fa-solid fa-calendar-alt"></i> ${task.deadline}</span>
                    <div class="task-actions">
                        <button class="action-btn toggle-complete" data-index="${index}">
                            <i class="fa-solid fa-${task.completed ? 'undo' : 'check'}"></i>
                        </button>
                        <button class="action-btn edit-task" data-index="${index}">
                            <i class="fa-solid fa-edit"></i>
                        </button>
                        <button class="action-btn delete-task danger" data-index="${index}">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
            tasksContainer.appendChild(taskEl);
        });

        updateCounters();
    }

    // Função para atualizar os contadores
    function updateCounters() {
        totalTasksEl.textContent = tasks.length;
        completedTasksEl.textContent = tasks.filter(task => task.completed).length;
    }

    // Função para alternar o status de conclusão da tarefa
    function toggleComplete(index) {
        if (tasks[index]) {
            tasks[index].completed = !tasks[index].completed;
            saveTasks();
            renderTasks();
        }
    }

    // Função para editar uma tarefa
    function editTask(index) {
        const task = tasks[index];
        if (task) {
            document.getElementById('title').value = task.title;
            document.getElementById('description').value = task.description;
            document.getElementById('priority').value = task.priority;
            document.getElementById('deadline').value = task.deadline;

            document.getElementById('taskForm').setAttribute('data-index', index);
            openModal();
        }
    }

    // Função para excluir uma tarefa
    function deleteTask(index) {
        if (tasks[index]) {
            tasks.splice(index, 1);
            saveTasks();
            renderTasks();
        }
    }

    // Função para salvar as tarefas no localStorage
    function saveTasks() {
        localStorage.setItem('tasks', JSON.stringify(tasks));
    }

    // Função para abrir o modal
    function openModal() {
        modal.style.display = 'block';
    }

    // Função para fechar o modal
    function closeModal() {
        modal.style.display = 'none';
        document.getElementById('taskForm').reset();
        document.getElementById('taskForm').removeAttribute('data-index');
    }

    // Evento para fechar o modal ao clicar fora dele
    window.onclick = (event) => {
        if (event.target === modal) {
            closeModal();
        }
    };

    // Evento para fechar o modal ao clicar no botão "X"
    document.querySelector('.close-modal').addEventListener('click', closeModal);

    // Evento para lidar com a criação ou edição de tarefas
    document.getElementById('taskForm').addEventListener('submit', (e) => {
        e.preventDefault();

        const title = document.getElementById('title').value.trim();
        const description = document.getElementById('description').value.trim();
        const priority = document.getElementById('priority').value;
        const deadline = document.getElementById('deadline').value;

        if (!title || !deadline) {
            alert('Por favor, preencha todos os campos obrigatórios.');
            return;
        }

        const index = document.getElementById('taskForm').getAttribute('data-index');

        if (index !== null && tasks[index]) {
            // Edição de tarefa
            tasks[index] = { title, description, priority, deadline, completed: tasks[index].completed };
        } else {
            // Nova tarefa
            tasks.push({ title, description, priority, deadline, completed: false });
        }

        saveTasks();
        renderTasks();
        closeModal();
    });

    // Eventos para os botões de ação nas tarefas
    tasksContainer.addEventListener('click', (e) => {
        if (e.target.classList.contains('toggle-complete')) {
            const index = parseInt(e.target.closest('.action-btn').dataset.index);
            toggleComplete(index);
        } else if (e.target.classList.contains('edit-task')) {
            const index = parseInt(e.target.closest('.action-btn').dataset.index);
            editTask(index);
        } else if (e.target.classList.contains('delete-task')) {
            const index = parseInt(e.target.closest('.action-btn').dataset.index);
            deleteTask(index);
        }
    });

    // Evento para filtrar tarefas
    document.querySelectorAll('.filter-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            document.querySelector('.filter-btn.active')?.classList.remove('active');
            button.classList.add('active');
            renderTasks(e.target.dataset.filter);
        });
    });

    function renderTasks() {
        taskCards.innerHTML = '';
        tasks.forEach((task, index) => {
            const card = document.createElement('div');
            card.className = `task-card ${task.priority ? 'priority-' + task.priority : ''}`;
            card.innerHTML = `
                <div class="task-card-header">
                    <h3 class="task-card-title">${task.title}</h3>
                    <span class="task-status">${task.completed ? '✅' : '⏳'}</span>
                </div>
                <div class="task-progress">
                    <div class="task-progress-bar" style="width: ${task.completed ? '100' : '30'}%"></div>
                </div>
                <div class="task-card-details">
                    <p>${task.description}</p>
                    <div class="task-card-meta">
                        <span class="task-deadline">📅 ${task.deadline}</span>
                        <div class="task-card-actions">
                            <button class="btn-edit" onclick="editTask(${index})">✏️</button>
                            <button class="btn-delete" onclick="deleteTask(${index})">🗑️</button>
                        </div>
                    </div>
                </div>
            `;
            
            // Interatividade de clique para expandir
            card.addEventListener('click', (e) => {
                if(!e.target.closest('button')) { // Evita trigger ao clicar em botões
                    card.classList.toggle('active');
                }
            });
    
            taskCards.appendChild(card);
        });
    }
});