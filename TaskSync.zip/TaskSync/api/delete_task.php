<?php
include '../includes/db.php';

//$creator = $_POST["creator"];
$task = $_POST['task'];
$message = "Tarefa deletada com sucesso";
$result = true;
try{
    $query = $conn->prepare("DELETE from tarefas where id=?");
    $query->execute([$task]);
} catch(PDOException $e){
    $message = "Erro ao deletar tarefa";
    $result = false;
}

echo json_encode(["message"=>$message, "result"=>$result]);
?>