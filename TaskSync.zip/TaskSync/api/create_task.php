<?php
include '../includes/db.php';

$creator = $_POST["creator"];
$title = $_POST['title'];
$description = $_POST['description'];
$deadline = $_POST['deadline'];
//$assigned_to = $_POST['assigned_to'];
$message = "Tarefa criada com sucesso";
$result = true;
try{
    $query = $conn->prepare("INSERT INTO tarefas(title, description, status, deadline, creator_id) VALUES (?, ?, 'incompleta', ?, ?)");
    $query->execute([$title, $description, $deadline, $creator]);
} catch(PDOException $e){
    $message = "Erro na criação da tarefa";
    $result = false;
}

echo json_encode(["message"=>$message, "result"=>$result]);
?>
