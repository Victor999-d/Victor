<?php
include '../includes/db.php';

$creator = $_POST["creator"];
$message = "";
$result = [];

try{
    $query = $conn->prepare("SELECT id, title, description, deadline, status from tarefas where ((SELECT accepted from usuarios_tarefas where tarefa_id=tarefas.id and usuario_id= ?) = 1 or tarefas.creator_id = ?)");
    $query->execute([$creator, $creator]);

    $result = $query->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e){
    $message = "Erro na criação da tarefa";
}

echo json_encode(["message"=>$message, "data"=>$result]);
?>
