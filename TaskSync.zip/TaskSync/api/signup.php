<?php
// Criar conexão
//$conn = new mysqli($servername, $username, $password, $dbname);
include("../includes/db.php");
//var_dump($conn);

$username = $_POST['username'];
$email = $_POST['email'];
$senha = md5($_POST['senha']); // Criptografar a senha
$message = "";

$consulta = $conn->prepare("SELECT username from usuarios WHERE email = ?");
$consulta->execute([$email]);
$data = $consulta->fetchAll(
    PDO::FETCH_ASSOC
);

//var_dump($data);
if($data == array()){
    $consulta = $conn->prepare("INSERT INTO usuarios(username, password, email) values(?, ?, ?)");
    $consulta->execute([$username, $senha, $email]);
} else {
    $message = "Email já cadastrado";
}
//$consulta = $conn->prepare("INSERT INTO usuarios(username, password, email) values(?, ?, ?)");
//$consulta->execute([$username, $senha, $email]);

// Verificar conexão
//if ($conn->connect_error) {
//  die("Conexão falhou: " . $conn->connect_error);
//}

// Verificar se o formulário foi enviado
/*if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT); // Criptografar a senha

    // Preparar e vincular
    $stmt = $conn->prepare("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)");
    $stmt->bind_param("sss" ,$nome, $email, $senha);

    // Executar a consulta
    if ($stmt->execute()) {
        echo "Registro criado com sucesso!";
    } else {
        echo "Erro: " . $stmt->error;
    }

    // Fechar a declaração e a conexão
    $stmt->close();
}
*/
echo json_encode(["message"=>$message]);
?>
