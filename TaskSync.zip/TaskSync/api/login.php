<?php
// Criar conexão
//$conn = new mysqli($servername, $username, $password, $dbname);
include("../includes/db.php");
//var_dump($conn);

//$username = $_POST['username'];
$email = $_POST['email'];
$senha = md5($_POST['senha']); // Criptografar a senha
$message = "";
$response = [];

$consulta = $conn->prepare("SELECT username, password, id from usuarios WHERE email = ? and password = ?");
$consulta->execute([$email, $senha]);
$data = $consulta->fetchAll(
    PDO::FETCH_ASSOC
);

//var_dump($data);
if($data != array()){
    $response = $data[0];
} else {
    $message = "Dados inválidos";
}

echo json_encode(["message"=>$message, "data"=>$response]);
?>
