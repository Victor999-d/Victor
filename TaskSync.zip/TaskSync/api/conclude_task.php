<?php
include '../includes/db.php';

//$creator = $_POST["creator"];
$task = $_POST['task'];
$message = "Tarefa concluída com sucesso";
$result = true;
try{
    $query = $conn->prepare("UPDATE tarefas set status = 'completa' where id=?");
    $query->execute([$task]);
} catch(PDOException $e){
    $message = "Erro ao completar tarefa";
    $result = false;
}

echo json_encode(["message"=>$message, "result"=>$result]);
?>
