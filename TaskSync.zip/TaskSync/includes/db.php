<?php
/*$host = 'localhost';
$user = 'root';
$password = '';
$database = 'task_management';
*/
//$conn = new mysqli($host, $user, $password, $database);
$conn = new PDO("mysql:host=localhost;dbname=task_management", "root",  "");
?>
