
var btnSignin = document.querySelector("#signin");
var btnSignup = document.querySelector("#signup");

var body = document.querySelector("body");


btnSignin.addEventListener("click", function () {
    body.className = "sign-in-js"; 
    inputName.value = ""
    inputPass.value = ""
    inputEmail.value = ""
});

btnSignup.addEventListener("click", function () {
    body.className = "sign-up-js";
    loginPass.value = ""
    loginEmail.value = ""
})

signupBtn.addEventListener("click", async function () {
    nome = inputName.value
    pass = inputPass.value
    email = inputEmail.value

    if(!validarCadastro(inputName, inputEmail, inputPass))
        return false;
    formdata = new FormData();
    formdata.append("username", nome);
    formdata.append("email", email);
    formdata.append("senha", pass);

    let obj = await fetch("../api/signup.php", {
        method: "POST",
        body: formdata
    })

    let res = await obj.json();
    if(res.message)
        alert(res.message)
    else{
        inputName.value = "";
        inputPass.value = "";
        inputEmail.value = "";
        body.className = "sign-in-js";
        alert("Cadastrado com sucesso!")
    }

    //console.log(formdata)
    //console.log(res)

})

signinBtn.addEventListener("click", async function () {
    //nome = inputName.value
    pass = loginPass.value
    email = loginEmail.value

    formdata = new FormData();
    formdata.append("email", email);
    formdata.append("senha", pass);

    let obj = await fetch("../api/login.php", {
        method: "POST",
        body: formdata
    })

    let res = await obj.json();
    if(res.message)
        alert(res.message)
    else{
        //inputName.value = "";
        //inputPass.value = "";
        //inputEmail.value = "";
        //body.className = "sign-in-js";
        //alert("Cadastrado com sucesso!")
        localStorage.setItem("id", res.data.id);
        localStorage.setItem("nome", res.data.username);
        localStorage.setItem("senha", res.data.password);
        location.href = "../"
    }

    //console.log(formdata)
    //console.log(res)

})

function  validarCadastro(nome, email, senha) {
  let letras = /[aA-zZ]/;
  let numeros = /[0-9]/;
  let arroba = /[\@]/;
  let espaco = /[\ ]/;
  let simbolos = /[\\\!\"\#\£\$\§\%\&\/\(\{\[\)\]\=\}\?\'\«\»\´\`\+\¨\*\~\^\º\ª\_\,\;\:\>\<]/;

  if(nome.value == "" || email.value == "" || senha.value == ""){
    alert("Preencha todos os campos");
    return false;
  }
  else if(!letras.test(nome.value)){
    alert("O nome deve conter letras");
    return false;
  }
  else if(numeros.test(nome.value)){
    alert("O nome não deve conter números");
    return false;
  }
  else if(simbolos.test(nome.value) || arroba.test(nome.value)){
    alert("O nome não deve conter símbolos");
    return false;
  }
  else if(!arroba.test(email.value)){
    alert("O email deve conter o @");
    return false;
  }
  else if(espaco.test(email.value)){
    alert("O email não deve conter espaços");
    return false;
  }
  else if(!letras.test(email.value)){
    alert("O email deve conter letras");
    return false;
  }
  else if(senha.value.length < 6){
    alert("Senha muito curta | min: 6");
    return false;
  }
  else
    return true;
}


function verifyAccount(){
    id_ = localStorage.getItem("id");
    nome_ = localStorage.getItem("nome");
    senha_ = localStorage.getItem("senha");
        

    if(id_ && nome_ && senha_)
        location.href = "../"
}

verifyAccount()
setInterval(()=>{
    verifyAccount()
}, 500)