<?php
include '../includes/db.php'; // Conexão com o banco

$username = $_POST['username'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Criptografar senha

// Verificar se o email ou username já existem
$checkQuery = "SELECT * FROM usuarios WHERE email = ? OR username = ?";
$stmtCheck = $conn->prepare($checkQuery);
$stmtCheck->bind_param("ss", $email, $username);
$stmtCheck->execute();
$result = $stmtCheck->get_result();

if ($result->num_rows > 0) {
    echo "Erro: Usuário ou email já cadastrado!";
} else {
    // Inserir o novo usuário
    $query = "INSERT INTO usuarios (username, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sss", $username, $email, $password);

    if ($stmt->execute()) {
        echo "Usuário registrado com sucesso!";
    } else {
        echo "Erro ao registrar usuário: " . $conn->error;
    }

    $stmt->close();
}

$stmtCheck->close();
$conn->close();
?>
