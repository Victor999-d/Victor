<?php
session_start();
include '../includes/db.php'; // Conexão com o banco

$email = $_POST['email'];
$password = $_POST['password'];

// Validar campos
if (empty($email) || empty($password)) {
    echo "Erro: Todos os campos são obrigatórios.";
    exit;
}

// Limitar tentativas de login por IP
$ip_address = $_SERVER['REMOTE_ADDR'];
$query = "SELECT COUNT(*) AS attempts FROM login_attempts WHERE ip_address = ? AND attempt_time > (NOW() - INTERVAL 15 MINUTE)";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $ip_address);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row['attempts'] >= 5) {
    echo "Erro: Muitas tentativas de login. Tente novamente em 15 minutos.";
    exit;
}

// Consultar usuário
$query = "SELECT * FROM usuarios WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

    if (password_verify($password, $user['password'])) {
        $_SESSION['username'] = $user['username'];
        $_SESSION['user_id'] = $user['id'];

        session_regenerate_id(); // Segurança contra sequestro de sessão

        echo "Login bem-sucedido!";
    } else {
        registrarTentativa($ip_address, $conn);
        echo "Erro: Senha incorreta.";
    }
} else {
    registrarTentativa($ip_address, $conn);
    echo "Erro: Usuário não encontrado.";
}

// Função para registrar tentativas de login
function registrarTentativa($ip_address, $conn) {
    $query = "INSERT INTO login_attempts (ip_address) VALUES (?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $ip_address);
    $stmt->execute();
}

$conn->close();

// Gerar código OTP
$user_id = $user['id'];
$otp_code = random_int(100000, 999999);

// Inserir o OTP no banco
$query = "INSERT INTO otps (user_id, otp_code) VALUES (?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("is", $user_id, $otp_code);
$stmt->execute();

// Enviar OTP por email
$to = $user['email'];
$subject = "Seu código OTP";
$message = "Seu código de verificação é: $otp_code";
$headers = "From: noreply@exemplo.com";

if (mail($to, $subject, $message, $headers)) {
    echo "Código OTP enviado para o seu email.";
    // Redirecionar para página de validação do OTP
    header("Location: verify_otp.php");
    exit;
} else {
    echo "Erro ao enviar o código OTP.";
}
?>