<?php
session_start();
include '../includes/db.php';

$user_id = $_SESSION['user_id'];
$otp_code = $_POST['otp_code'];

// Verificar o OTP
$query = "SELECT * FROM otps WHERE user_id = ? AND otp_code = ? AND expiration_time > NOW()";
$stmt = $conn->prepare($query);
$stmt->bind_param("is", $user_id, $otp_code);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "Autenticação multifator bem-sucedida!";
    // Redirecionar para o dashboard
    header("Location: ../dashboard.php");
} else {
    echo "Erro: Código OTP inválido ou expirado.";
}
?>
